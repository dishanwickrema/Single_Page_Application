
function markerSize(population) {
  return population / 20;
}

var locations = [
  {
    coordinates: [43.85, -79.02],
    region: {
      name: "Ajax",
      population: 121780
    }
  },
  {
    coordinates: [43.83, -79.87],
    region: {
      name: "Caledon",
      population: 72900
    }
  },
  {
    coordinates: [43.58, -79.64],
    region: {
      name: "Mississauga",
      population: 726359
    }
  },
  {
    coordinates: [43.92, -79.52],
    region: {
      name: "King",
      population: 24512
    }
  },
  {
    coordinates: [44.38, -79.69],
    region: {
      name: "Barrie",
      population: 141434
    }
  },
  {
    coordinates: [43.85, -79.33],
    region: {
      name: "Markham",
      population: 301709
    }
  },
  {
    coordinates: [43.88, -79.44],
    region: {
      name: "Richmond Hill",
      population: 195022
    }
  },
  {
    coordinates: [43.85, -79.50],
    region: {
      name: "Vaughan",
      population: 323281
    }
  },
  {
    coordinates: [43.73, -79.76],
    region: {
      name: "Brampton",
      population: 603346
    }
  },
  {
    coordinates: [43.65, -79.38],
    region: {
      name: "Toronto",
      population: 2930000
    }
  },
  {
    coordinates: [44.10, -80.48],
    region: {
      name: "Durham",
      population: 683600
    }
  },
  {
    coordinates: [43.53, -79.87],
    region: {
    
        name : "Halton",
        population: 548435
      }
    },
    {
      coordinates: [43.69, -79.45],
      region: {
        name : "York",
        population: 1110000
      }
    }, 
    {
      coordinates: [44.05, -80.18],
      region: {
        name : "Duffrin",
        population: 61735
      }
    }, 
    {
      coordinates: [42.83, -80.30],
      region: {
        name : "Simcoe",
        population: 13922
      } 
    }
  ];

  
// // Define arrays to hold created region markers
var regionMarkers = [];

// Loop through locations and create city and state markers
for (var i = 0; i < locations.length; i++) {
//   // Setting the marker radius for the state by passing population into the markerSize function
//   regionMarkers.push(
//     L.marker(locations[i].coordinates, {
//       stroke: false,
//       fillOpacity: 0.75,
//       color: "red",
//       fillColor: "white",
//       radius: markerSize(locations[i].region.population)
//       })
//   );
// }

// Define variables for our base layers

API_KEY  = "pk.eyJ1IjoiYmFuYWZzaGUiLCJhIjoiY2swc3d5bDg1MDdlcDNocG92ZGltZGg0ZSJ9.bXiVYEWfgPNVEIiVNBK4dA"
var streetmap = L.tileLayer("https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}", {
  attribution: "Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors, <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">CC-BY-SA</a>, Imagery © <a href=\"https://www.mapbox.com/\">Mapbox</a>",
  maxZoom: 18,
  id: "mapbox.streets",
  accessToken: API_KEY
});

var darkmap = L.tileLayer("https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}", {
  attribution: "Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors, <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">CC-BY-SA</a>, Imagery © <a href=\"https://www.mapbox.com/\">Mapbox</a>",
  maxZoom: 18,
  id: "mapbox.dark",
  accessToken: API_KEY
});

// Create a separate layer for regions
var regions = L.layerGroup(regionMarkers);

// Create a baseMaps object
var baseMaps = {
  "Street Map": streetmap,
  "Dark Map": darkmap
};

// Create an overlay object

var overlayMaps = {
"Region Population": regions
};

// Define a map object

var mymap = L.map("mymap", {
  center: [43.65, -79.38],
  zoom: 7,
  layers: [streetmap, regions]
});
// Pass our map layers into our layer control
// Add the layer control to the map
L.control.layers(baseMaps, overlayMaps, {
  collapsed: false

}).addTo(mymap);
 


// Create a red circle over Toronto
L.circle([43.6532, -79.3832], {
    color: "yellow",
    fillColor: "yellow",
    fillOpacity: 0.75,
    radius:10000
  }).addTo(mymap);

// Create a red polygon that covers the area in GTA
L.polygon([
[43.83, -79.87],
[43.58, -79.64],
[43.92, -79.52],
[44.38, -79.69],
[43.85, -79.33],
[43.88, -79.44],
[43.85, -79.50],
[43.73, -79.76],
[43.65, -79.38],
[44.10, -80.48],
[43.53, -79.87],
[43.69, -79.45],
[44.05, -80.18],
[42.83, -80.30]
],{
  color: "red",
  fillColor: "red",
  fillOpacity: 0.75
}).addTo(mymap);

// Loop through the regions array and create one marker for each city object
for (var i = 0; i < cities.length; i++) {
  L.circle(coordinates[i].coordinates, {
    fillOpacity: 0.75,
    color: "white",
    fillColor: "purple",
    // Setting our circle's radius equal to the output of our markerSize function
    // This will make our marker's size proportionate to its population
    radius: markerSize(coordinates[i].population)
  }).bindPopup("<h1>" + coordinates[i].name + "</h1> <hr> <h3>Population: " + coordinates[i].population + "</h3>").addTo(mymap);
}